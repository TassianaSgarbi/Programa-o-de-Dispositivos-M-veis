import { useState } from 'react'

import { View, Text, Button, TextInput, Switch, Image } from 'react-native'

import {styles} from './styles'

import {Picker} from '@react-native-picker/picker'

import Slider from '@react-native-community/slider';
 

export default function App(){

const [resultado, setResultado] = useState()

const [nome, setNome] = useState()

const [idade, setIdade] = useState()

const [sexo, setSexo] = useState()

const [escolaridade, setEscolaridade] = useState()

const [limite, setLimite] = useState()

const [nacionalidade, setNacionalidade] = useState()

const [valor, setValor] = useState(0)

const [status, setStatus] = useState(false)


function getSexoLabel(value) {
  switch (value) {
    case 1:
      return "Feminino";
    case 2:
      return "Masculino";
    case 3:
      return "Prefiro não Informar";
    default:
      return "";
  }
}

function getEscolaridadeLabel(value) {
  switch (value) {
    case 2:
      return "Ensino Fundamental";
    case 3:
      return "Ensino Médio";
    case 4:
      return "Ensino Superior";
    case 5:
      return "Sem Escolaridade";
    default:
      return "";
  }
}


function confirmarCadastro(){

  let dados = 'Nome: ' + nome + '\nIdade: ' + idade + ' anos' + '\nSexo: ' + getSexoLabel(sexo) + '\nEscolaridade: ' + getEscolaridadeLabel(escolaridade) + '\nLimite: ' + valor;

  if (status) {
    dados += '\nBrasileiro: Sim';
  } else {
    dados += '\nBrasileiro: Não';
  }

  setResultado(dados);
}


  

 
return(

    <View>

      <Text style={styles.titulo}>Abertura de Conta</Text>

     <View style={{flexDirection:'row'}}>


      <Text style={styles.titulo}>Nome:</Text>


  <TextInput

      style={styles.input}

      placeholder=""

      onChangeText={setNome}


      />

</View>
     
   
  <View style={{flexDirection:'row'}}>

      <Text style={styles.titulo}>Idade:</Text>


  <TextInput

      style={styles.input}

      placeholder=""

      onChangeText={setIdade}


      />

</View>

   
 <View style={{flexDirection:'row'}}>

      <Text style={styles.titulo}>Sexo:</Text>

 <Picker
selectedValue={sexo}
onValueChange={ (itemValue, itemIndex) => setSexo(itemIndex) }
 
 >

      <Picker.Item key={1} value={0} label="" />
      <Picker.Item key={2} value={1} label="Feminino" />
      <Picker.Item key={3} value={2} label="Masculino" />
      <Picker.Item key={4} value={3} label="Prefiro não Informar" />

      
      
    </Picker>  


</View>

    <View style={{flexDirection:'row'}}>

<Text style={styles.titulo}>Escolaridade:</Text>
 
 <Picker
selectedValue={escolaridade}
onValueChange={ (itemValue, itemIndex) => setEscolaridade(itemIndex) }
 >

      <Picker.Item key={1} value={1} label="" />
      <Picker.Item key={1} value={2} label="Ensino Fundamental" />
      <Picker.Item key={2} value={3} label="Ensimo Médio" />
      <Picker.Item key={3} value={"Ensino Superior"} label="Ensino Superior" />
      <Picker.Item key={4} value={5} label="Sem Escolaridade" />

  

    </Picker>
 



    </View>
 
 <View style={{flexDirection:'row'}}>

<Text style={styles.titulo}>Limite:</Text>

  <Slider
        minimumValue={0}
        maximumValue={5000}
        onValueChange={ (valorSelecionado) => setValor(valorSelecionado) }
        value={valor}
        step={200}
        minimumTrackTintColor='green'
        maximumTrackTintColor='black'
        thumbTintColor='blue'

      />


      <Text style={{textAlign: 'center', fontSize: 30}}>
        {valor.toFixed(0)}
      </Text>

 



    </View>
 
 <View style={{flexDirection:'row'}}>

<Text style={styles.titulo}>Brasileiro:</Text>

 <Switch
      value={status}
      onValueChange={ (valorSwitch) => setStatus(valorSwitch) }
      />


      <Text style={{textAlign: 'center', fontSize:30}}>
      {(status) ? "Sim" : "Não"}

      </Text>


  </View>

 <View>

      <Button title='Confirmar'

      onPress={confirmarCadastro}/>



        <Text style={styles.resultado}>{resultado}</Text>

  </View>

    </View>

  
);   
}
import { useState } from 'react'
import { View, Text, Button, TextInput } from 'react-native'
import {styles} from './styles'


export default function App(){
  const [numero1, setNumero1] = useState(0)
  const [numero2, setNumero2] = useState(0)
  const [resultado, setResultado] = useState('')

  function calcular(){
        r = numero1 * numero2
    setResultado('Resultado: ' + r)
  }

  return(
    <View>

      <Text style={styles.texto}>Multiplicador de Números</Text>

      <TextInput
      style={styles.input}
      placeholder="Digite o primeiro nº"
      onChangeText={setNumero1}
      />

      <TextInput
      style={styles.input}
      placeholder="Digite o segundo nº"
      onChangeText={setNumero2}
      />      

      <Button title='Calcular' color='green' onPress={calcular} />

      <Text style={styles.texto}>{resultado}</Text>      
    </View>
  );
}
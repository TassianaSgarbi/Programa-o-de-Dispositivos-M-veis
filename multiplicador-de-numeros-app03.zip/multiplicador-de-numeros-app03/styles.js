import {StyleSheet} from 'react-native'


const styles = StyleSheet.create({
  texto:{
    fontSize: 20,
    color:'orange',
    marginTop: 15,
    textAlign: 'center'
  },
  contador: {
    fontSize: 80,
    textAlign: 'center',
    color: 'blue'
  },
  input:{
    height: 45,
    borderWidth: 1,
    borderColor: '#222',
    margin: 10,
    borderRadius: 20,
    fontSize: 20,
    padding: 10,
  },

})


export {styles}
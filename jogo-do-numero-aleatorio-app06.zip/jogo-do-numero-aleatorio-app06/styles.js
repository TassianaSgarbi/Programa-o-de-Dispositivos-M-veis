import {StyleSheet} from 'react-native'

 
const styles = StyleSheet.create({

  titulo:{

    fontSize: 20,

    color:'black',

    marginTop: 15,

    textAlign: 'center',
    
    height: 50
    

  },

   titulo2:{

    fontSize: 20,

    color:'red',

    marginTop: 15,

    textAlign: 'center',
    
    height: 50
    

  },

  imagem: {

    width: 100,

    height: 100,

    alignSelf: 'center',

 

  },

 

  resultado: {

    fontSize: 30,

    textAlign: 'center',

    color: 'black'

  },

 
 

})

 


export {styles}
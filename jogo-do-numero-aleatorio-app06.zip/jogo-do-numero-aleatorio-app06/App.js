import React, { useState } from 'react';
import { View, Text, Button, Image } from 'react-native';
import { styles } from './styles';

export default function App() {
  const [resultado, setResultado] = useState(null);

  function gerarNumeroAleatorio() {
    const numeroAleatorio = Math.floor(Math.random() * 11);
    setResultado(numeroAleatorio);
  }

  return (
    <View>
      <Text style={styles.titulo}>Jogo do Nº Aleatório</Text>

      <Image
        source={require('./Imagem/charada.png')}
        style={styles.imagem}
      />

      <Text style={styles.titulo2}>Pense em um nº de 0 a 10</Text>

      <Text style={styles.resultado}>{resultado}</Text>

      <Button
        title='Descobrir'
        color='blue'
        onPress={gerarNumeroAleatorio}
      />
    </View>
  );
}


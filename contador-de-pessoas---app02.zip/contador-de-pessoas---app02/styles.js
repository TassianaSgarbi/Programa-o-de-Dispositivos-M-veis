import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'orange',
  },
  contador: {
    textAlign: 'center',
    color: 'red',
    fontSize: 100
  },
  greenButton: {
    marginLeft: 10,
    marginRight: 10
  },
  redButton: {
    marginLeft: 10,
    marginRight: 10,
    paddingTop: 20
  }
});
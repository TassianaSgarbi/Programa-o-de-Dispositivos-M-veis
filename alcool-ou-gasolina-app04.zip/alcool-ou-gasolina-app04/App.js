import { useState } from 'react'

import { View, Text, Button, TextInput, Image } from 'react-native'

import {styles} from './styles'

 

 

 

 

export default function App(){

  const [resultado, setResultado] = useState()

  const [numero1, setNumero1] = useState()

  const [numero2, setNumero2] = useState()

 

  function calcularMelhorOpcao(){

    if ((numero1/numero2)<= 0.7){

      setResultado('Melhor opção ÁLCOOL')

    }  

    else

      setResultado('Melhor opção GASOLINA')

     

  }

 

 

 

  return(

    <View>

      <Text style={styles.titulo}>Alcool ou Gasolina</Text>

 

      <Image

          style={styles.imagem}

          source={{ uri:'https://vault.pulsarimagens.com.br/file/preview/32ER396.jpg'}}

         

      />

 

 

 

      <TextInput

      style={styles.input}

      placeholder="Preço do Álcool"

      onChangeText={setNumero1}

      />

 

 

      <TextInput

      style={styles.input}

      placeholder="Preço da Gasolina"

      onChangeText={setNumero2}

      />

 

 

      <Button title='Verificar

      ' color='green' onPress={(calcularMelhorOpcao)}

      />

 

 

      <Text style={styles.resultado}>{resultado}</Text>

 

 

 

 

 

 

 

 

    </View>

  )

}
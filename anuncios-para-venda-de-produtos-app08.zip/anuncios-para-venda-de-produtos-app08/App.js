import { View, StyleSheet, ScrollView, Text, Image } from 'react-native';

import React, { Component } from 'react';

function App() {
  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.titulo}>Anúncios</Text>
      </View>
      <View style={styles.mainContainer}>
        <View style={styles.window}>
          <ScrollView horizontal={true} style={styles.scrollContainer}>
            <View style={[styles.box1, { width: 150, marginRight: 20 }]}>
              <Image
                style={styles.imagem1}
                source={{
                  uri: 'https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/inspiron-notebooks/15-3525/media-gallery/updated/in3525nt-cnb-05000ff090-bk-fpr.psd?fmt=png-alpha&pscan=auto&scl=1&hei=402&wid=606&qlt=100,1&resMode=sharp2&size=606,402&chrss=full',
                }}
              />

              <Text style={styles.text}>
                Notebook Inspiron 15 3000 AMD Ryzen
              </Text> 
              <Text style={styles.text1}>
              Processador AMD Ryzen 5 5500U
              Windows 11
              Placa de vídeo AMD Radeon
              Memória de 8GB DDR4
              SSD de 256GB
              Tela Full HD de 15.6
              Preço: R$ 2.997,00
              </Text>
            </View>
            <View style={[styles.box2, { width: 150, marginRight: 20 }]}>
              <Image
                style={styles.imagem2}
                source={{
                  uri: 'https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/desktops/inspiron-desktops/24-5420/media-gallery/gray/desktop-aio-inspiron-24-5420-gray-gallery-2.psd?fmt=png-alpha&pscan=auto&scl=1&hei=402&wid=546&qlt=100,1&resMode=sharp2&size=546,402&chrss=full',
                }}
              />

              <Text style={styles.text}>
                Inpiron 24 All in One 
              </Text>
              <Text style={styles.text1}>
              Intel® Core™ i7-1355U 
              Windows 11 Home
              Placa de vídeo Intel® Iris® Xe com memória gráfica compartilhada
              Memória de 16GB DDR4
              SSD de 512GB
              Tela IPS Full HD de 23.8" 
              Preço: R$ 5.799,00
              </Text>
            </View>
            <View style={[styles.box3, { width: 150 }]}>
              <Image
                style={styles.imagem3}
                source={{
                  uri: 'https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/desktops/inspiron-desktops/inspiron-3020/media-gallery/desktop-inspiron-3020-noodd-nomcr-gallery-13.psd?fmt=png-alpha&pscan=auto&scl=1&hei=402&wid=312&qlt=100,1&resMode=sharp2&size=312,402&chrss=full',
                }}
              />

              <Text style={styles.text}>
                Inspiron Desktop
              </Text>
              <Text style={styles.text1}>
              Processador Intel® Core™ i5-13400F
              Windows 11 Home
              Placa de vídeo NVIDIA® GeForce® GTX 1660 SUPER™, 6GB GDDR6
              Memória de 16GB DDR4
              SSD de 512GB
              
              Preço: R$ 5.398,00
              </Text>
            </View>
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // container: {
  //   flex: 1,
  //   justifyContent: 'center', // Centraliza os itens verticalmente
  //   alignItems: 'center', // Centraliza os itens horizontalmente
  //   borderWidth: 1,
  //   borderColor: 'black',
  //   height: 250,
  // },
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  mainContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    paddingVertical: 32,
    marginTop: 10,
  },
  window: {
    borderWidth: 2,
    borderColor: 'gray',
    width: 350,
    padding: 16,
    marginTop: 20,
    marginBottom: 20,
  },
  titulo: {
    fontSize: 20,
    color: 'red',
    marginTop: 15,
    textAlign: 'center',
    flexDirection: 'column',
    top: 50,
  },
  scrollContainer: {
    flexDirection: 'row',
  },
  box1: {
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'gray',
    marginBottom: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
  },
  imagem1: {
    width: 120,
    height: 120,
    resizeMode: 'cover',
    marginBottom: 8,
  },
  box2: {
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'gray',
    marginBottom: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
  },
  imagem2: {
    width: 120,
    height: 120,
    resizeMode: 'cover',
    marginBottom: 8,
  },
  box3: {
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'gray',
    marginBottom: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
  },
  imagem3: {
    width: 120,
    height: 120,
    resizeMode: 'cover',
    marginBottom: 8,
  },
  text: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  text1: {
    fontSize: 16,
    textAlign: 'center',
  },
});

export default App;;
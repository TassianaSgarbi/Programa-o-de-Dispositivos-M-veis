import { useState } from 'react'

import { View, Text, Button, TextInput, Image } from 'react-native'

import {styles} from './styles'

 

 

 

 

export default function App(){

  const [resultado, setResultado] = useState()

  const [peso, setPeso] = useState()

  const [altura, setAltura] = useState()

 

  function classificacaoImc(){

    imc = peso/(altura*altura)

   

    if (imc < 18.5)

      setResultado('Abaixo do Peso')

    else if (imc <= 24.9)

      setResultado('Peso Normal')

    else if (imc <= 29.9)

      setResultado('Sobrepeso')

    else if (imc <= 34.9)

      setResultado('Obesidade Grau I')

    else if (imc <= 39.9)

      setResultado('Obesidade Grau II')

    else

      setResultado('Obesidade Grau III ou Mórbida')

     

  }

 

 

  return(

    <View>

      <Text style={styles.titulo}>Cálculo do IMC</Text>

 

      <Image

          style={styles.imagem}

          source={{ uri:'https://a-static.mlcdn.com.br/450x450/balanca-digital-corporal-bioimpedancia-historico-bluetooth-sq/maisvantagens/p2016/cdeb2c4b9bb87b9615154bc382eae8a3.jpeg'}}

         

      />

 

 

 

      <TextInput

      style={styles.input}

      placeholder="Peso"

      onChangeText={setPeso}

      />

 

 

      <TextInput

      style={styles.input}

      placeholder="Altura"

      onChangeText={setAltura}

      />

 

 

      <Button title='Verificar

      ' color='green' onPress={(classificacaoImc)}

      />

 

 

      <Text style={styles.resultado}>{resultado}</Text>

 

 

 

 

 

 

 

 

    </View>

  )

}

 
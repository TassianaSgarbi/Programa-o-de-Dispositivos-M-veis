import { View, StyleSheet, ScrollView, Text } from 'react-native';

function App() {
  return (
    <View style={styles.container}>
      <View style={styles.box0}>Vagas</View>
      <ScrollView>

        <View style={[styles.box1, styles.spacing]}>

        <Text style={styles.text}>Desenvolvedor Backend</Text>
        <Text style={styles.text}>Salario: R$ 3.000,00</Text>
        <Text style={styles.text}>Descrição: O profissional será responsável pelo aplicativos web do lado servidor.</Text>
        <Text style={styles.text}>Contato: E-mail vagas.vagas1@gmail.com</Text>
        </View>
        
        <View style={[styles.box2, styles.spacing]}>
         <Text style={styles.text}>Engenheiro de Dados</Text> 
         <Text style={styles.text}>Salario: R$ 7.000,00</Text>
         <Text style={styles.text}>Descrição: O profissional será responsável por gerenciar, otimizar, supervisionar e monitorar a recuperação, armazenamento e distribuição de dados em toda a organização </Text>
         <Text style={styles.text}>Contato: E-mail vagas.vagas1@gmail.com </Text>
        </View>

        <View style={[styles.box3, styles.spacing]}>
         <Text style={styles.text}>Analista de Dados </Text>
         <Text style={styles.text}>Salario: R$ 5.000,00</Text>
         <Text style={styles.text}>Descrição: O profissional será responsável por desenvolver e implementar análises de dados, sistemas de coleta de dados e outras estratégias que otimizem a eficiência e a qualidade estatística. </Text>
         <Text style={styles.text}>Contato: E-mail vagas.vagas1@gmail.com </Text>
        </View>

        <View style={[styles.box4, styles.spacing]}>
         <Text style={styles.text}>Gerente de Projetos</Text>
         <Text style={styles.text}>Salario: R$ 35.000,00</Text>
         <Text style={styles.text}>Descrição: O profissional será responsável por gerenciar projetos, planejar sua execução, acompanhar o escopo estabelecido e o progresso das rotinas, a fim de cumprir metas, prazos e custos estabelecidos. Identificar os riscos para estudar formas de mitigar impactos e corrigir ações. </Text>
         <Text style={styles.text}>Contato: E-mail vagas.vagas1@gmail.com</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  box0: {
    backgroundColor: 'white',
    height: 100,
    color: 'red',
    fontSize: 40,
    alignItems: 'center',
  },
  box1: {
    backgroundColor: 'red',
    height: 200,
    width: 400,
    color: 'black',
    fontSize: 30 ,
    borderWidth: 4,
    borderColor: 'black',
    borderRadius: 5,
    alignItems: '',
  },
  box2: {
    backgroundColor: 'green',
    height: 250,
    width: 400,
    color: 'black',
    fontSize: 30,
    borderWidth: 4,
    borderColor: 'black',
    borderRadius: 5,
  },
  box3: {
    backgroundColor: 'yellow',
    height: 250,
    width: 400,
    color: 'black',
    fontSize: 30,
    borderWidth: 4,
    borderColor: 'black',
    borderRadius: 5,
    alignItems: ''
  },
  box4: {
    backgroundColor: 'blue',
    height: 330,
    width: 400,
    color: 'black',
    fontSize: 30,
    borderWidth: 4,
    borderColor: 'black',
    borderRadius: 5,
  },
  spacing: {
    marginBottom: 10, // Espaço inferior
    marginTop: 10, // Espaço superior
  },
  text: {
    fontSize: 20, // Ajuste o tamanho da fonte conforme necessário
  },
});

export default App;

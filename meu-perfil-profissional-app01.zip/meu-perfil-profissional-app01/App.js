import { Text, StyleSheet, View, Image } from 'react-native';

 

export default function App() {

  return (

   <View>

      <Text style={styles.tituloApp}>App Meu Perfil</Text>

        <View style={styles.containerImagem}>

          <Image

source={ require('./imagens/tassiana.png')}

            style={styles.imagem}

          />

          <Image

source={ require('./imagens/alexandra.png')}

            style={styles.imagem}

          />

        </View>

        <View style={styles.container}>

          <Text style={styles.titulo}>Dados Pessoais:</Text>

            <Text>

              <Text style={styles.nome}>Nome: </Text>

                   Tassiana Sgarbi Frazão da Silva {'\n'}

                {/*Idade: 35 anos {'\n'}

                Estado Civil: Namorando {'\n'}

                {'\n'}*/}

 

              <Text style={styles.nome}>Nome: </Text>

                   Alexandra Aparecida da Costa {'\n'}

                {/*Idade: 47 anos {'\n'}

                Estado Civil: Solteira {'\n'}*/}

         
            

            {'\n'}

            </Text>

 

          <Text style={styles.titulo}>Formacao:</Text>

            <Text>

                  - Graduando em Analise e Desenvolvimento de Sistemas {'\n'}

              {'\n'}       

            </Text>

            

          <Text style={styles.titulo}>Experiencia:</Text>

            <Text>

                - Atua na area Tributaria e Societaria há certa de 17 anos. {'\n'}

                - Atua no setor publico na Area Administrativa e RH há 10 anos. {'\n'}

            

            {'\n'}

            </Text>

            

          <Text style={styles.titulo}>Projetos:</Text>

            <Text>

                - Implantação de sistemas contábeis com diversos programas como: TOTVS Protheus e Sankhya. {'\n'}

                - Implementação de um sitema de Gerencimaneto de Usinas de Asflato na cidade de Santos. {'\n'}

          

            </Text>

        </View>

      </View>

  );

}

 

const styles = StyleSheet.create({

  tituloApp: {

    fontWeight: 'bold',

    textAlign: 'center',

    fontSize: 20

  },

  container: {

    justifyContent: 'center',

    backgroundColor: '#ecf0f1',

    padding: 8,

    overflow: 'auto'

  },

  titulo: {

    fontWeight: 'bold',

    textAlign: 'center'

  },

  imagem: {

    width: 60,

    height: 60,

  },

  containerImagem: {

    flex: 1,

    alignItems: 'center',

    justifyContent: 'space-around',

    flexDirection: 'row',

    paddingTop: 10,

    paddingBottom: 10,

    paddingLeft: 10,

    paddingRight: 10,

  },

  nome: {

    fontWeight: 'bold'

  }

});